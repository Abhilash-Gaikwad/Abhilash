﻿using MovieApplication.Model;
using MovieApplication.Reference;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace MovieApplication
{
    public partial class MovieTime : Form
    {
        public List<Movie> MovieList { get; set; }
        public List<MovieRef> LatestMovieList { get; set; }
        public List<MovieRef> FilteredMovieList { get; set; }
        public List<string> GenreList { get; set; }

        public int rowCount = 0;

        /// <summary>
        /// Constructor for initializing component and calling  GetJsonData method for populating data on datagrid.
        /// </summary>
        public MovieTime()
        {
            InitializeComponent();
            GetJsonData();
        }

        /// <summary>
        ///  GetJsonData method parse json file and populate latest 4 movie details on datagrid.
        /// </summary>
        public void GetJsonData()
        {
            try
            {
                string jsonFilePath = Application.StartupPath + @"\moviedata.json";
                string jsonView = File.ReadAllText(jsonFilePath);

                MovieList = JsonConvert.DeserializeObject<List<Movie>>(jsonView);

                LatestMovieList = new List<MovieRef>();
                MovieList.OrderByDescending(i => i.Year).Take(4).ToList().ForEach(item =>
                {
                    LatestMovieList.Add(new MovieRef()
                    {
                        Title = item.Title,
                        ReleaseDate = item.Info.Release_date,
                        Year = item.Year
                    });
                });

                dataGridView1.DataSource = LatestMovieList;

                GenreList = new List<string>();
                GenreList.Add("Select Genre");
                foreach (var movie in MovieList)
                {
                    if (movie.Info.Genres != null)
                    {
                        foreach (var genre in movie.Info.Genres)
                        {
                            if (!GenreList.Contains(genre))
                                GenreList.Add(genre);
                        }
                    }
                }

                cmbGenres.DataSource = GenreList;
            }
            catch(Exception)
            {
                MessageBox.Show("Voucher file not present at location : " + Application.StartupPath, "Error", MessageBoxButtons.OK);
            }

            lblMlist.Text = "Latest 4 Movies available";
            
            rowCount = dataGridView1.RowCount;            
            lblRowCnt.Text = "Row Count:" + rowCount;
        }

        /// <summary>
        /// Method for finding data depending on filter set by user and show it on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            var searchTitle = txtTitle.Text;
            var searchGenre = cmbGenres.SelectedValue;
            var searchYear = txtYear.Text;

            try
            {
                if (searchYear == string.Empty && searchTitle == string.Empty && searchGenre.ToString() == "Select Genre")
                {
                    var result = MessageBox.Show("You have not entered search criteria. This will fetch all the movie list from database. " +
                                    "Do you want to continue", "Warning", MessageBoxButtons.YesNo);
                    if (result == DialogResult.No)
                    {
                        return;
                    }

                }

                FilteredMovieList = new List<MovieRef>();
                MovieList.Where(item =>
                {

                    if ((searchYear == string.Empty || (searchYear != string.Empty && item.Year == (searchYear)))
                   && (searchTitle == string.Empty || (searchTitle != string.Empty && item.Title.ToUpper().Contains(searchTitle.ToUpper())))
                   && (searchGenre.ToString() == "Select Genre" || (item.Info.Genres != null && item.Info.Genres.Contains(searchGenre))))
                    {
                        return true;
                    }
                    return false;

                }
                ).ToList().ForEach(item =>
                {
                    FilteredMovieList.Add(new MovieRef()
                    {
                        Title = item.Title,
                        ReleaseDate = item.Info.Release_date,
                        Year = item.Year
                    });
                }); ;

                dataGridView1.DataSource = FilteredMovieList;
            }
            catch (Exception)
            {
                MessageBox.Show("Can not search movies as Database not available.", "Error", MessageBoxButtons.OK);
            }
            

            lblMlist.Text = "Movies as per your search criteria";

            rowCount = dataGridView1.RowCount;
            lblRowCnt.Text = "Row Count:" + rowCount;
        }

        /// <summary>
        /// This method clears data set on datagrid after users filter and 
        /// set latest 4 movies on datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                txtTitle.Text = string.Empty;
                cmbGenres.SelectedIndex = 0;
                txtYear.Text = string.Empty;
                dataGridView1.DataSource = LatestMovieList;
                rowCount = dataGridView1.RowCount;
                lblMlist.Text = "Latest 4 Movies available";
                lblRowCnt.Text = "Row Count:" + rowCount;
            }
            catch (Exception)
            {
                MessageBox.Show("No data populated to Clear!", "Error", MessageBoxButtons.OK);
            }

        }

        /// <summary>
        /// This method sets details of movie selected from datagrid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetail_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows != null)
                {
                    var selectedRow = dataGridView1.SelectedRows[0];
                    var selectedYear = selectedRow.Cells[0].Value.ToString();
                    var selectedTitle = selectedRow.Cells[1].Value.ToString();
                    var movieDetail = MovieList.SingleOrDefault(item => item.Title == selectedTitle && item.Year == selectedYear);
                    FrmMovieDetail frmload = new FrmMovieDetail(movieDetail);
                    frmload.Show();
                }
                else
                {
                    MessageBox.Show("Please select movie from the list", "Error", MessageBoxButtons.OK);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No movie details availble to show.", "Error", MessageBoxButtons.OK);
            }


        }

    }
}
