﻿namespace MovieApplication
{
    partial class FrmMovieDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblMname = new System.Windows.Forms.Label();
            this.pctMovie = new System.Windows.Forms.PictureBox();
            this.lblReleaseD = new System.Windows.Forms.Label();
            this.lblRelD = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDirN = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblRating = new System.Windows.Forms.Label();
            this.Generes = new System.Windows.Forms.Label();
            this.lblGener = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRank = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblRnSec = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblActor = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPlot = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctMovie)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblPlot);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblActor);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lblRnSec);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.lblRank);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lblGener);
            this.panel1.Controls.Add(this.Generes);
            this.panel1.Controls.Add(this.lblRating);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblDirN);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblRelD);
            this.panel1.Controls.Add(this.lblReleaseD);
            this.panel1.Controls.Add(this.lblMname);
            this.panel1.Controls.Add(this.pctMovie);
            this.panel1.Location = new System.Drawing.Point(27, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1293, 474);
            this.panel1.TabIndex = 2;
            // 
            // lblMname
            // 
            this.lblMname.AutoSize = true;
            this.lblMname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMname.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMname.Location = new System.Drawing.Point(44, 29);
            this.lblMname.Name = "lblMname";
            this.lblMname.Size = new System.Drawing.Size(99, 32);
            this.lblMname.TabIndex = 2;
            this.lblMname.Text = "label1";
            this.lblMname.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pctMovie
            // 
            this.pctMovie.ErrorImage = global::MovieApplication.Properties.Resources.ImgNA;
            this.pctMovie.InitialImage = global::MovieApplication.Properties.Resources.Loading;
            this.pctMovie.Location = new System.Drawing.Point(41, 103);
            this.pctMovie.Name = "pctMovie";
            this.pctMovie.Size = new System.Drawing.Size(299, 359);
            this.pctMovie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctMovie.TabIndex = 1;
            this.pctMovie.TabStop = false;
            // 
            // lblReleaseD
            // 
            this.lblReleaseD.AutoSize = true;
            this.lblReleaseD.Location = new System.Drawing.Point(370, 103);
            this.lblReleaseD.Name = "lblReleaseD";
            this.lblReleaseD.Size = new System.Drawing.Size(107, 20);
            this.lblReleaseD.TabIndex = 3;
            this.lblReleaseD.Text = "Release Date";
            // 
            // lblRelD
            // 
            this.lblRelD.AutoSize = true;
            this.lblRelD.Location = new System.Drawing.Point(536, 103);
            this.lblRelD.Name = "lblRelD";
            this.lblRelD.Size = new System.Drawing.Size(33, 20);
            this.lblRelD.TabIndex = 4;
            this.lblRelD.Text = "Rel";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Directors";
            // 
            // lblDirN
            // 
            this.lblDirN.AutoSize = true;
            this.lblDirN.Location = new System.Drawing.Point(536, 142);
            this.lblDirN.Name = "lblDirN";
            this.lblDirN.Size = new System.Drawing.Size(29, 20);
            this.lblDirN.TabIndex = 6;
            this.lblDirN.Text = "Dir";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(370, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Rating";
            // 
            // lblRating
            // 
            this.lblRating.AutoSize = true;
            this.lblRating.Location = new System.Drawing.Point(536, 180);
            this.lblRating.Name = "lblRating";
            this.lblRating.Size = new System.Drawing.Size(101, 20);
            this.lblRating.TabIndex = 8;
            this.lblRating.Text = "Movie Rating";
            // 
            // Generes
            // 
            this.Generes.AutoSize = true;
            this.Generes.Location = new System.Drawing.Point(370, 215);
            this.Generes.Name = "Generes";
            this.Generes.Size = new System.Drawing.Size(62, 20);
            this.Generes.TabIndex = 9;
            this.Generes.Text = "Genres";
            // 
            // lblGener
            // 
            this.lblGener.AutoSize = true;
            this.lblGener.Location = new System.Drawing.Point(536, 215);
            this.lblGener.Name = "lblGener";
            this.lblGener.Size = new System.Drawing.Size(0, 20);
            this.lblGener.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(370, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Rank";
            // 
            // lblRank
            // 
            this.lblRank.AutoSize = true;
            this.lblRank.Location = new System.Drawing.Point(536, 249);
            this.lblRank.Name = "lblRank";
            this.lblRank.Size = new System.Drawing.Size(47, 20);
            this.lblRank.TabIndex = 12;
            this.lblRank.Text = "Rank";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(370, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Running time(Sec)";
            // 
            // lblRnSec
            // 
            this.lblRnSec.AutoSize = true;
            this.lblRnSec.Location = new System.Drawing.Point(536, 282);
            this.lblRnSec.Name = "lblRnSec";
            this.lblRnSec.Size = new System.Drawing.Size(60, 20);
            this.lblRnSec.TabIndex = 14;
            this.lblRnSec.Text = "runSec";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Actors";
            // 
            // lblActor
            // 
            this.lblActor.AutoSize = true;
            this.lblActor.Location = new System.Drawing.Point(536, 317);
            this.lblActor.Name = "lblActor";
            this.lblActor.Size = new System.Drawing.Size(0, 20);
            this.lblActor.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(371, 351);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Movie Plot";
            // 
            // lblPlot
            // 
            this.lblPlot.AutoSize = true;
            this.lblPlot.Location = new System.Drawing.Point(536, 351);
            this.lblPlot.MaximumSize = new System.Drawing.Size(700, 0);
            this.lblPlot.Name = "lblPlot";
            this.lblPlot.Size = new System.Drawing.Size(81, 20);
            this.lblPlot.TabIndex = 18;
            this.lblPlot.Text = "Movie Plot";
            // 
            // FrmMovieDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 500);
            this.Controls.Add(this.panel1);
            this.Name = "FrmMovieDetail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMovieDetail";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctMovie)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pctMovie;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMname;
        private System.Windows.Forms.Label lblReleaseD;
        private System.Windows.Forms.Label lblRelD;
        private System.Windows.Forms.Label lblDirN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRating;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Generes;
        private System.Windows.Forms.Label lblGener;
        private System.Windows.Forms.Label lblRank;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRnSec;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblActor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPlot;
        private System.Windows.Forms.Label label6;
    }
}