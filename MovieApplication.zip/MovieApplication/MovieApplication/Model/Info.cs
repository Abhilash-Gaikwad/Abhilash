﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MovieApplication.Model
{
    public class Info
    {
        public List<string> Directors { get; set; }
        public DateTime Release_date { get; set; }
        public string Rating { get; set; }
        public List<string> Genres { get; set; }
        public string Image_url { get; set; }
        public string Plot { get; set; }
        public int Rank { get; set; }
        public double Running_time_secs { get; set; }
        public List<string> Actors { get; set; }
    }
}
