﻿using MovieApplication.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieApplication
{
    public partial class FrmMovieDetail : Form
    {
        public Movie MovieDetails { get; set; }

        /// <summary>
        /// Constructor to initialize component
        /// </summary>
        /// <param name="detail"></param>
        public FrmMovieDetail(Movie detail)
        {
            MovieDetails = detail;
            InitializeComponent();
            this.Load += FrmMovieDetail_Load;
        }

        /// <summary>
        /// This method set details of movie selected from datagrid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMovieDetail_Load(object sender, EventArgs e)
        {
            try
            {
                //Display Image
                if (!string.IsNullOrEmpty(MovieDetails.Info.Image_url))
                    pctMovie.LoadAsync(MovieDetails.Info.Image_url);
                else
                    pctMovie.Image = pctMovie.ErrorImage;

                //Display Title
                if (!string.IsNullOrEmpty(MovieDetails.Title))
                    lblMname.Text = MovieDetails.Title;

                //Display Release Date
                if (!string.IsNullOrEmpty(MovieDetails.Info.Release_date.ToString()))
                {
                    DateTime tmp = MovieDetails.Info.Release_date;
                    lblRelD.Text = tmp.ToString("yyyy-MM-dd HH':'mm':'ss");
                }
                else
                    lblRelD.Text = "Release Date not available";

                //Display Directors Names
                if (MovieDetails.Info.Directors != null)
                {
                    foreach (object item in MovieDetails.Info.Directors)
                    {
                        if (MovieDetails.Info.Directors.Count == 1)
                            lblDirN.Text += item + ".";
                        else
                            lblDirN.Text += item + ",";

                    }
                }
                else
                    lblDirN.Text = "Director details not available";

                //Display rating
                if (!string.IsNullOrEmpty(MovieDetails.Info.Rating))
                    lblRating.Text = MovieDetails.Info.Rating;
                else
                    lblRating.Text = "Movie Rating not available";

                //Display Genres
                if (MovieDetails.Info.Genres != null)
                {
                    foreach (object item in MovieDetails.Info.Genres)
                    {
                        if (MovieDetails.Info.Genres.Count == 1)
                            lblGener.Text += item + ".";
                        else
                            lblGener.Text += item + ",";
                    }
                }
                else
                    lblGener.Text = "Director details not available";

                //Display Rank
                if (!string.IsNullOrEmpty(MovieDetails.Info.Rank.ToString()))
                    lblRank.Text = MovieDetails.Info.Rank.ToString();
                else
                    lblRank.Text = "Movie Rank not available";

                //Display Movie Time
                if (!string.IsNullOrEmpty(MovieDetails.Info.Running_time_secs.ToString()))
                    lblRnSec.Text = MovieDetails.Info.Running_time_secs.ToString();

                //Display Actor Details
                if (MovieDetails.Info.Actors != null)
                {
                    foreach (object item in MovieDetails.Info.Actors)
                    {
                        if (MovieDetails.Info.Actors.Count == 1)
                            lblActor.Text += item + ".";
                        else
                            lblActor.Text += item + ",";
                    }
                }
                else
                    lblActor.Text = "Actors details not available";

                //Display Movie Plot
                lblPlot.AutoSize = true;
                if (!string.IsNullOrEmpty(MovieDetails.Info.Plot.ToString()))
                    lblPlot.Text = MovieDetails.Info.Plot.ToString();
                else
                    lblPlot.Text = "Movie Plot not available";
            }
            catch (Exception)
            {
                MessageBox.Show("Issue populating details.", "Error", MessageBoxButtons.OK);
            }
        }
    }
}
